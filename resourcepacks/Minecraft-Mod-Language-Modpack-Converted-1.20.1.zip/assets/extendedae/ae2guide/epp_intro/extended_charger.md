---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 扩展充能器
    icon: extendedae:ex_charger
categories:
- extended devices
item_ids:
- extendedae:ex_charger
---

# 扩展充能器

<Row gap="20">
<BlockImage id="extendedae:ex_charger" scale="8"></BlockImage>
</Row>

扩展充能器是一种更高级的<ItemLink id="ae2:charger" />。

它最多可以同时充能4个物品。
