---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Concurrent Processor
    icon: extendedae:concurrent_processor
categories:
- extended foundation
item_ids:
- extendedae:concurrent_processor
- extendedae:concurrent_processor_press
- extendedae:concurrent_processor_print
---

# Concurrent Processor

<Row>
<ItemImage id="extendedae:concurrent_processor" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_press" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_print" scale="4"></ItemImage>
</Row>

Concurrent Processor is commonly used in multi-thread machines, so they can handle multiple works at the same time.
