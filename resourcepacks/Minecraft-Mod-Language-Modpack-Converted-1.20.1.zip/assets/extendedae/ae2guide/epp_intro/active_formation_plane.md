---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME主动成型面板
    icon: extendedae:active_formation_plane
categories:
- extended devices
item_ids:
- extendedae:active_formation_plane
---

# ME主动成型面板

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_active_formation_plane.snbt"></ImportStructure>
</GameScene>

ME主动成型面板是<ItemLink id="ae2:formation_plane" />的升级版，它会主动放置出方块或输出掉落物。

你不需要为它设置子网。它的工作原理类似于<ItemLink id="ae2:export_bus" />，但它放置方块而不是输出到容器。
